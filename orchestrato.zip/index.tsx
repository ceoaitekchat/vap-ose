/* tslint:disable */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {GoogleGenAI, LiveServerMessage, Modality, Session} from '@google/genai';
import {LitElement, css, html} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import {createBlob, decode, decodeAudioData} from './utils';
import './visual-3d';

import { initializeApp, FirebaseApp } from "firebase/app";
import { getDatabase, ref, push, set, serverTimestamp, onValue, Database, Unsubscribe } from "firebase/database";

const DEFAULT_SYSTEM_PROMPT = `system
You are WorkflowPro GPT, built by Aitek PH Software to help users design, organize, and optimize workflows, flowcharts, and process diagrams across any industry.

**🧰 Core Capabilities**  
- Analyze complex processes, spot bottlenecks, and suggest improvements  
- Support BPMN, UML, flowcharts, mind maps, decision trees, and more  
- Generate clear documentation to accompany each workflow  

**📑 Structured Breakdown Template**  
When a user asks for a detailed process or system flow, use this adaptable “Shorts AutoPilot”–inspired format:  
1. **🖥️ Pages & UI** – Key screens, layout, and navigation paths  
2. **🔄 Step-by-Step Workflow** – Numbered stages, substeps, and tools involved  
3. **📡 API Configuration** – Endpoints, data models, authentication, integrations  
4. **⚙️ Backend Setup** – Server logic or functions powering each automation  
5. **🧱 Tech Stack** – Frameworks, libraries, databases, deployment strategies  

**🖼️ Visual Diagrams**  
- Render each flow using Mermaid syntax for flowcharts, sequence diagrams, etc.  
- Include Mermaid code so users can preview, tweak, and export as PNG  

**✍️ Communication Style**  
- Always address the user as **Master E**, with respectful but friendly tone.  
- Taglish tone: approachable yet professional, with light banter or emojis when fitting  
- Adjustable technical depth: from “walk-you-through” for business users to “deep-dive” for devs  
- Clear notation, concise labels, and helpful annotations  

**🤔 Clarification & Optimization**  
- If request is vague, ask targeted questions before mapping  
- Propose process improvements, automation opportunities, and redundancy checks  

Always aim for clarity, structure, and precision—making even the most intricate workflows easy to understand and implement for **Master E**.`;

const AVAILABLE_VOICES = [
  'Orus', 'Nova', 'Echo', 'Lyra', 'Sirius', 'Luna', 'Stella', 'Sol', 'Atlas', 'Aurora',
  'Stardust', 'Zephyr', 'Comet', 'Celeste', 'Orion', 'Andromeda', 'Nebula', 'Cosmos', 'Galaxy', 'Quasar'
] as const;
const DEFAULT_VOICE: typeof AVAILABLE_VOICES[number] = 'Orus';
const DEFAULT_OUTPUT_SAMPLE_RATE = 24000;

const LOCAL_STORAGE_KEYS = {
  SYSTEM_PROMPT: 'app.settings.systemPrompt',
  SELECTED_VOICE: 'app.settings.selectedVoice',
  OUTPUT_SAMPLE_RATE: 'app.settings.outputSampleRate',
};

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBe9a58zaQCrBSGeWwcIVa_PnZABoH6zV4", // This is a public client-side key
  authDomain: "tudds-ccd0wn.firebaseapp.com",
  databaseURL: "https://tudds-ccd0wn-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "tudds-ccd0wn",
  storageBucket: "tudds-ccd0wn.appspot.com",
  messagingSenderId: "786974954352",
  appId: "1:786974954352:web:5f933f5a2f9f386d9bb5b5",
  measurementId: "G-YKTV36XJFS"
};

interface ConversationMessage {
  speaker: 'model' | 'user' | 'system';
  text: string;
  timestamp: number; // Firebase server timestamp
}

interface ConversationMeta {
  startTime: number;
  systemPrompt?: string;
  voice?: string;
  sampleRate?: number;
}

interface Conversation {
  id: string;
  meta: ConversationMeta;
  messages: Record<string, ConversationMessage>;
}

@customElement('gdm-live-audio')
export class GdmLiveAudio extends LitElement {
  @state() isRecording = false;
  @state() status = '';
  @state() error = '';
  @state() currentPage: 'main' | 'settings' = 'main';

  // Settings state
  @state() systemPrompt: string = DEFAULT_SYSTEM_PROMPT;
  @state() selectedVoice: typeof AVAILABLE_VOICES[number] = DEFAULT_VOICE;
  @state() outputSampleRate: number = DEFAULT_OUTPUT_SAMPLE_RATE;

  // Chat History State
  @state() showChatHistory = false;
  @state() chatConversations: Conversation[] | null = null;
  @state() chatLoadingError: string | null = null;
  @state() isChatLoading = false;
  private chatHistoryUnsubscribe: Unsubscribe | null = null;


  private client: GoogleGenAI;
  private session: Session;
  
  private inputAudioContext = new (window.AudioContext ||
    (window as any).webkitAudioContext)({sampleRate: 16000});
  private outputAudioContext: AudioContext;
  
  @state() inputNode = this.inputAudioContext.createGain();
  @state() outputNode: GainNode;

  private nextStartTime = 0;
  private mediaStream: MediaStream;
  private sourceNode: AudioBufferSourceNode;
  private scriptProcessorNode: ScriptProcessorNode;
  private sources = new Set<AudioBufferSourceNode>();

  private firebaseApp: FirebaseApp;
  private firebaseDb: Database;
  @state() private currentConversationId: string | null = null;

  static styles = css`
    :host {
      display: block;
      width: 100%;
      height: 100%;
      position: relative;
      overflow: hidden; /* Prevent scrollbars from appearing due to off-screen panel */
    }

    .app-container {
      width: 100%;
      height: 100%;
      position: relative;
    }

    #status {
      position: absolute;
      bottom: 5vh;
      left: 0;
      right: 0;
      z-index: 10;
      text-align: center;
      color: white;
      font-family: sans-serif;
    }

    .controls {
      z-index: 10;
      position: absolute;
      bottom: 10vh;
      left: 0;
      right: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      gap: 10px;

      button {
        outline: none;
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.1);
        width: 64px;
        height: 64px;
        cursor: pointer;
        font-size: 24px;
        padding: 0;
        margin: 0;
        display: flex;
        align-items: center;
        justify-content: center;

        &:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      }

      button[disabled] {
        opacity: 0.5;
        cursor: not-allowed;
      }
      button#startButton[disabled], button#stopButton[disabled] {
         display: none; /* Keep original behaviour for start/stop */
      }
    }
    
    .icon-button { /* Generic class for header icons */
      position: absolute;
      top: 20px;
      z-index: 20;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 50%;
      width: 48px;
      height: 48px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white; /* For SVG fill if not overridden */
    }
    .icon-button:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    .icon-button svg {
      fill: currentColor; /* Inherit color from button */
    }

    .settings-icon-button {
      right: 20px;
    }
    
    .chat-icon-button {
      left: 20px;
    }


    .settings-page {
      padding: 20px;
      color: white;
      font-family: sans-serif;
      display: flex;
      flex-direction: column;
      gap: 20px;
      max-width: 600px;
      margin: 40px auto;
      background: rgba(0,0,0,0.3);
      border-radius: 8px;
      height: calc(100% - 80px); /* Adjust if needed */
      overflow-y: auto;
    }
    .settings-page h2 {
      text-align: center;
      margin-top:0;
    }
    .settings-page label {
      display: block;
      margin-bottom: 5px;
    }
    .settings-page input[type="number"],
    .settings-page select,
    .settings-page textarea {
      width: 100%;
      padding: 10px;
      border-radius: 4px;
      border: 1px solid #555;
      background-color: #333;
      color: white;
      box-sizing: border-box;
    }
    .settings-page textarea {
      min-height: 150px;
      resize: vertical;
    }
    .settings-page button {
      padding: 12px 20px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s;
    }
    .settings-page button:hover {
      background-color: #45a049;
    }

    /* Chat History Panel Styles */
    .chat-history-panel {
      position: fixed;
      top: 0;
      left: 0;
      width: 85%;
      max-width: 500px; /* Max width on larger screens */
      height: 100%;
      background-color: #1e1e1e; /* Dark background from chat.html */
      color: #e0e0e0;
      box-shadow: 2px 0 10px rgba(0,0,0,0.5);
      transform: translateX(-100%);
      transition: transform 0.3s ease-in-out;
      z-index: 1000; /* Ensure it's on top */
      display: flex;
      flex-direction: column;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }
    .chat-history-panel.visible {
      transform: translateX(0);
    }
    .chat-history-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 20px;
      background-color: #2a2a2a; /* Slightly different header bg */
      border-bottom: 1px solid #333;
    }
    .chat-history-header h1 {
      margin: 0;
      font-size: 1.5em;
      color: #bb86fc;
    }
    .close-chat-button {
      background: none;
      border: none;
      color: #e0e0e0;
      cursor: pointer;
      padding: 5px;
    }
    .close-chat-button svg {
      width: 28px;
      height: 28px;
      fill: #e0e0e0;
    }
    .close-chat-button:hover svg {
      fill: #bb86fc;
    }
    .chat-history-content {
      flex-grow: 1;
      overflow-y: auto;
      padding: 20px;
    }
    .chat-history-content .error-message {
      color: #cf6679; /* Material error color */
    }
    .conversation {
        margin-bottom: 30px;
        padding: 15px;
        border: 1px solid #333;
        border-radius: 6px;
        background-color: #2a2a2a;
    }
    .conversation h2 {
        font-size: 1.2em;
        margin-top: 0;
        color: #bb86fc;
        border-bottom: 1px solid #444;
        padding-bottom: 8px;
    }
    .messages-list {
        margin-top: 15px;
    }
    .message {
        margin-bottom: 15px;
        padding: 10px;
        border-radius: 4px;
    }
    .system-message, .model-message {
        background-color: #333333;
        border-left: 3px solid #bb86fc; /* Model's color */
    }
    .message strong {
        display: block;
        margin-bottom: 5px;
        color: #03dac6; /* Accent for speaker name */
    }
    .message .message-text {
        white-space: pre-wrap;
        word-wrap: break-word;
    }
    .message .message-text pre { /* Style for pre tags within message-text */
        margin: 0;
        font-family: inherit; /* Inherit from .message-text */
        background-color: transparent; /* Remove default pre background if formatMessageText adds its own */
        padding: 0;
    }
    .message .message-text .mermaid-codeblock {
        background-color: #252525;
        padding: 10px;
        border-radius: 4px;
        overflow-x: auto;
        border: 1px dashed #555;
    }
    .message .timestamp {
        font-size: 0.8em;
        color: #888;
        display: block;
        text-align: right;
        margin-top: 5px;
    }
  `;

  constructor() {
    super();
    this.loadSettings();
    this.initFirebase();
    this.initClient();
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    if (this.chatHistoryUnsubscribe) {
      this.chatHistoryUnsubscribe();
      this.chatHistoryUnsubscribe = null;
    }
    this.session?.close();
    this.inputAudioContext?.close();
    this.outputAudioContext?.close();
  }

  private initFirebase() {
    this.firebaseApp = initializeApp(firebaseConfig);
    this.firebaseDb = getDatabase(this.firebaseApp);
  }

  private loadSettings() {
    this.systemPrompt = localStorage.getItem(LOCAL_STORAGE_KEYS.SYSTEM_PROMPT) || DEFAULT_SYSTEM_PROMPT;
    const storedVoice = localStorage.getItem(LOCAL_STORAGE_KEYS.SELECTED_VOICE) as typeof AVAILABLE_VOICES[number];
    this.selectedVoice = AVAILABLE_VOICES.includes(storedVoice) ? storedVoice : DEFAULT_VOICE;
    this.outputSampleRate = parseInt(localStorage.getItem(LOCAL_STORAGE_KEYS.OUTPUT_SAMPLE_RATE) || DEFAULT_OUTPUT_SAMPLE_RATE.toString(), 10);
  }

  private saveSettings() {
    const form = this.shadowRoot?.querySelector('#settingsForm') as HTMLFormElement;
    if (form) {
      const formData = new FormData(form);
      this.systemPrompt = formData.get('systemPrompt') as string || DEFAULT_SYSTEM_PROMPT;
      this.selectedVoice = formData.get('selectedVoice') as typeof AVAILABLE_VOICES[number] || DEFAULT_VOICE;
      this.outputSampleRate = parseInt(formData.get('outputSampleRate') as string, 10) || DEFAULT_OUTPUT_SAMPLE_RATE;

      localStorage.setItem(LOCAL_STORAGE_KEYS.SYSTEM_PROMPT, this.systemPrompt);
      localStorage.setItem(LOCAL_STORAGE_KEYS.SELECTED_VOICE, this.selectedVoice);
      localStorage.setItem(LOCAL_STORAGE_KEYS.OUTPUT_SAMPLE_RATE, this.outputSampleRate.toString());
      
      this.currentConversationId = null; 
      this.updateStatus('Settings saved. Re-initializing session...');
      this.reset(); 
      this.navigateToMain();
    }
  }
  
  private initOutputAudioContext() {
    if (this.outputAudioContext && this.outputAudioContext.state !== 'closed') {
      this.outputAudioContext.close();
    }
    this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: this.outputSampleRate });
    this.outputNode = this.outputAudioContext.createGain();
    this.outputNode.connect(this.outputAudioContext.destination);
    this.nextStartTime = this.outputAudioContext.currentTime;
  }

  private resetPlaybackQueue() {
    for(const source of this.sources.values()) {
        source.stop();
        this.sources.delete(source);
    }
    this.nextStartTime = this.outputAudioContext?.currentTime ?? 0;
  }


  private async initClient() {
    this.initOutputAudioContext();

    this.client = new GoogleGenAI({
      apiKey: process.env.API_KEY, 
    });

    this.initSession();
  }

  private async initSession() {
    if (!this.outputAudioContext || this.outputAudioContext.state === 'closed') {
        this.initOutputAudioContext();
    }
    this.resetPlaybackQueue();

    const model = 'gemini-2.5-flash-preview-native-audio-dialog';
    
    try {
      this.session = await this.client.live.connect({
        model: model,
        callbacks: {
          onopen: () => {
            this.updateStatus('Connection Opened');
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.modelTurn?.parts) {
              for (const part of message.serverContent.modelTurn.parts) {
                if (part.inlineData && this.outputAudioContext) { // Audio part
                  const audio = part.inlineData;
                  this.nextStartTime = Math.max(
                    this.nextStartTime,
                    this.outputAudioContext.currentTime,
                  );

                  const audioBuffer = await decodeAudioData(
                    decode(audio.data),
                    this.outputAudioContext,
                    this.outputSampleRate,
                    1,
                  );
                  const source = this.outputAudioContext.createBufferSource();
                  source.buffer = audioBuffer;
                  source.connect(this.outputNode);
                  source.addEventListener('ended', () =>{
                    this.sources.delete(source);
                  });

                  source.start(this.nextStartTime);
                  this.nextStartTime = this.nextStartTime + audioBuffer.duration;
                  this.sources.add(source);
                } else if (part.text && this.currentConversationId) { // Text part
                    const messagesRef = ref(this.firebaseDb, `conversations/${this.currentConversationId}/messages`);
                    const newMessageRef = push(messagesRef);
                    set(newMessageRef, {
                        speaker: 'model',
                        text: part.text,
                        timestamp: serverTimestamp()
                    });
                }
              }
            }

            const interrupted = message.serverContent?.interrupted;
            if(interrupted) {
              this.resetPlaybackQueue();
            }
          },
          onerror: (e: ErrorEvent) => {
            this.updateError(`Error: ${e.message}`);
          },
          onclose: (e: CloseEvent) => {
            this.updateStatus(`Connection Closed: ${e.reason || 'Unknown reason'}`);
          },
        },
        config: {
          responseModalities: [Modality.AUDIO, Modality.TEXT],
          speechConfig: {
            voiceConfig: {prebuiltVoiceConfig: {voiceName: this.selectedVoice}},
          },
          systemInstruction: this.systemPrompt,
        },
      });
      this.updateStatus('Session initialized.');
    } catch (e) {
      console.error('Session initialization error:', e);
      this.updateError(`Failed to initialize session: ${(e as Error).message}`);
    }
  }

  private updateStatus(msg: string) {
    this.status = msg;
    this.error = ''; 
  }

  private updateError(msg: string) {
    this.error = msg;
  }

  private async startRecording() {
    if (this.isRecording) {
      return;
    }
    if (!this.session || this.session['connectionPromise'] === null) {
        this.updateStatus('Session not ready. Please wait or reset.');
        await this.initSession(); 
        if (!this.session || this.session['connectionPromise'] === null) {
           this.updateError('Failed to establish session. Please try resetting.');
           return;
        }
    }

    if (!this.currentConversationId) {
        this.currentConversationId = `conv_${Date.now()}`;
        const conversationMetaRef = ref(this.firebaseDb, `conversations/${this.currentConversationId}/meta`);
        set(conversationMetaRef, {
            startTime: serverTimestamp(),
            systemPrompt: this.systemPrompt,
            voice: this.selectedVoice,
            sampleRate: this.outputSampleRate
        });
    }

    this.inputAudioContext.resume();
    this.outputAudioContext.resume();


    this.updateStatus('Requesting microphone access...');

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      });

      this.updateStatus('Microphone access granted. Starting capture...');

      this.sourceNode = this.inputAudioContext.createMediaStreamSource(
        this.mediaStream,
      );
      this.sourceNode.connect(this.inputNode);

      const bufferSize = 256;
      this.scriptProcessorNode = this.inputAudioContext.createScriptProcessor(
        bufferSize,
        1,
        1,
      );

      this.scriptProcessorNode.onaudioprocess = (audioProcessingEvent) => {
        if (!this.isRecording) return;

        const inputBuffer = audioProcessingEvent.inputBuffer;
        const pcmData = inputBuffer.getChannelData(0);
        
        if (this.session && this.session['connectionPromise'] !== null) {
            this.session.sendRealtimeInput({media: createBlob(pcmData)});
        }
      };

      this.sourceNode.connect(this.scriptProcessorNode);
      
      this.isRecording = true;
      this.updateStatus('🔴 Recording... Capturing PCM chunks.');
    } catch (err) {
      console.error('Error starting recording:', err);
      this.updateStatus(`Error starting recording: ${(err as Error).message}`);
      this.stopRecording(); 
    }
  }

  private stopRecording() {
    if (!this.isRecording && !this.mediaStream && !this.inputAudioContext) {
      if (this.isRecording) this.isRecording = false; 
      return;
    }
    
    this.updateStatus('Stopping recording...');
    this.isRecording = false;

    if (this.scriptProcessorNode) {
        this.scriptProcessorNode.onaudioprocess = null; 
        this.scriptProcessorNode.disconnect();
        this.scriptProcessorNode = null as any; // Cast to any to satisfy TS strict null checks if it complains
    }
    if (this.sourceNode) {
        this.sourceNode.disconnect();
        this.sourceNode = null as any;
    }
    
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null as any;
    }
    
    this.updateStatus('Recording stopped. Click Start to begin again.');
  }

  private async reset() {
    this.stopRecording(); 
    this.currentConversationId = null; 
    this.session?.close();
    await this.initOutputAudioContext(); 
    await this.initSession(); 
    this.updateStatus('Session reset. New conversation log will be created on next recording.');
  }

  private navigateToSettings() {
    this.currentPage = 'settings';
  }

  private navigateToMain() {
    this.currentPage = 'main';
  }

  private toggleChatHistory() {
    this.showChatHistory = !this.showChatHistory;
    if (this.showChatHistory && !this.chatConversations && !this.chatHistoryUnsubscribe) {
      this.fetchChatHistory();
    } else if (!this.showChatHistory && this.chatHistoryUnsubscribe) {
      // Optional: Unsubscribe when panel is closed to save resources
      // this.chatHistoryUnsubscribe();
      // this.chatHistoryUnsubscribe = null;
      // this.chatConversations = null; // Clear data if you want to refetch next time
    }
  }

  private fetchChatHistory() {
    this.isChatLoading = true;
    this.chatLoadingError = null;
    const dbRef = ref(this.firebaseDb, 'conversations');
    
    this.chatHistoryUnsubscribe = onValue(dbRef, (snapshot) => {
      const conversationsData = snapshot.val();
      if (conversationsData) {
        const sortedConvIds = Object.keys(conversationsData).sort((a, b) => {
          const timeA = conversationsData[a].meta?.startTime || 0;
          const timeB = conversationsData[b].meta?.startTime || 0;
          return timeB - timeA; // Newest first
        });
        this.chatConversations = sortedConvIds.map(id => ({ id, ...conversationsData[id] }));
      } else {
        this.chatConversations = [];
      }
      this.isChatLoading = false;
    }, (error) => {
      console.error("Error fetching conversations:", error);
      this.chatLoadingError = `Failed to load chat history: ${error.message}`;
      this.isChatLoading = false;
    });
  }

  private escapeHtml(unsafe: any): string {
    if (unsafe === null || unsafe === undefined) return '';
    if (typeof unsafe !== 'string') unsafe = String(unsafe);
    return unsafe
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;");
  }

  private formatMessageText(text: string | null | undefined): string {
      if (text === null || text === undefined) return '';
      if (text.includes('```mermaid')) {
          const parts = text.split(/(```mermaid\n[\s\S]*?\n```)/g);
          return parts.map(part => {
              if (part.startsWith('```mermaid')) {
                  return `<pre class="mermaid-codeblock">${this.escapeHtml(part)}</pre>
                          <p><small>(Mermaid diagram code above. To render, copy into a Mermaid-enabled viewer.)</small></p>`;
              }
              // Escape other parts before wrapping in pre, if they aren't already escaped.
              // Assuming other parts might also contain characters needing escape.
              return `<pre>${this.escapeHtml(part)}</pre>`;
          }).join('');
      }
      return `<pre>${this.escapeHtml(text)}</pre>`;
  }
  
  renderMainPage() {
    return html`
      <button class="icon-button chat-icon-button" @click=${this.toggleChatHistory} title="Chat History" aria-label="Open chat history">
        <svg xmlns="http://www.w3.org/2000/svg" height="28px" viewBox="0 0 24 24" width="28px" aria-hidden="true">
          <path d="M0 0h24v24H0V0z" fill="none"/>
          <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12zM7 9h10v2H7zm0-3h10v2H7z"/>
        </svg>
      </button>
      <button class="icon-button settings-icon-button" @click=${this.navigateToSettings} title="Settings" aria-label="Open settings">
        <svg xmlns="http://www.w3.org/2000/svg" height="28px" viewBox="0 0 24 24" width="28px" aria-hidden="true">
          <path d="M0 0h24v24H0V0z" fill="none"/>
          <path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.08-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.08.49 0 .61-.22l2-3.46c.12-.22-.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/>
        </svg>
      </button>
      <div class="controls">
        <button
          id="resetButton"
          @click=${this.reset}
          ?disabled=${this.isRecording}
          title="Reset Session"
          aria-label="Reset session">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            height="40px"
            viewBox="0 -960 960 960"
            width="40px"
            fill="#ffffff"
            aria-hidden="true">
            <path
              d="M480-160q-134 0-227-93t-93-227q0-134 93-227t227-93q69 0 132 28.5T720-690v-110h80v280H520v-80h168q-32-56-87.5-88T480-720q-100 0-170 70t-70 170q0 100 70 170t170 70q77 0 139-44t87-116h84q-28 106-114 173t-196 67Z" />
          </svg>
        </button>
        <button
          id="startButton"
          @click=${this.startRecording}
          ?disabled=${this.isRecording}
          title="Start Recording"
          aria-label="Start recording">
          <svg
            viewBox="0 0 100 100"
            width="32px"
            height="32px"
            fill="#c80000"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true">
            <circle cx="50" cy="50" r="50" />
          </svg>
        </button>
        <button
          id="stopButton"
          @click=${this.stopRecording}
          ?disabled=${!this.isRecording}
          title="Stop Recording"
          aria-label="Stop recording">
          <svg
            viewBox="0 0 100 100"
            width="32px"
            height="32px"
            fill="#000000"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true">
            <rect x="0" y="0" width="100" height="100" rx="15" />
          </svg>
        </button>
      </div>

      <div id="status" role="status" aria-live="polite"> ${this.error || this.status} </div>
      <gdm-live-audio-visuals-3d
        .inputNode=${this.inputNode}
        .outputNode=${this.outputNode}></gdm-live-audio-visuals-3d>
    `;
  }

  renderSettingsPage() {
    return html`
      <div class="settings-page">
        <h2>Settings</h2>
        <form id="settingsForm" @submit=${(e: Event) => e.preventDefault()}>
          <div>
            <label for="systemPrompt">System Prompt:</label>
            <textarea id="systemPrompt" name="systemPrompt" .value=${this.systemPrompt} aria-label="System Prompt"></textarea>
          </div>
          <div>
            <label for="selectedVoice">Voice:</label>
            <select id="selectedVoice" name="selectedVoice" .value=${this.selectedVoice} aria-label="Select voice">
              ${AVAILABLE_VOICES.map(voice => html`<option value=${voice}>${voice}</option>`)}
            </select>
          </div>
          <div>
            <label for="outputSampleRate">Output Sample Rate (Hz):</label>
            <input type="number" id="outputSampleRate" name="outputSampleRate" .value=${this.outputSampleRate.toString()} min="8000" max="48000" step="1000" aria-label="Output Sample Rate in Hertz">
          </div>
          <button type="button" @click=${this.saveSettings} aria-label="Save settings">Save Settings</button>
        </form>
         <button type="button" @click=${this.navigateToMain} style="background-color: #777; margin-top: 10px;" aria-label="Back to main page">Back to Main</button>
      </div>
    `;
  }

  renderChatHistoryPage() {
    return html`
      <div class="chat-history-panel ${this.showChatHistory ? 'visible' : ''}" aria-hidden=${!this.showChatHistory}>
        <div class="chat-history-header">
          <h1>Chat History</h1>
          <button @click=${this.toggleChatHistory} class="close-chat-button" aria-label="Close chat history">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px">
              <path d="M0 0h24v24H0V0z" fill="none"/>
              <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/>
            </svg>
          </button>
        </div>
        <div class="chat-history-content">
          ${this.isChatLoading ? html`<p>Loading chat history...</p>` : ''}
          ${this.chatLoadingError ? html`<p class="error-message">${this.chatLoadingError}</p>` : ''}
          ${!this.isChatLoading && !this.chatLoadingError && this.chatConversations?.length === 0 ? html`<p>No conversations yet.</p>` : ''}
          ${!this.isChatLoading && !this.chatLoadingError && this.chatConversations?.map(conv => html`
            <div class="conversation" role="log">
              <h2>Conversation (${conv.meta?.startTime ? new Date(conv.meta.startTime).toLocaleString() : conv.id})</h2>
              ${conv.meta ? html`
                <div style="font-size: 0.9em; color: #aaa; margin-bottom: 10px;">
                  ${conv.meta.voice ? html`<strong>Voice:</strong> ${this.escapeHtml(conv.meta.voice)}<br>` : ''}
                  ${conv.meta.sampleRate ? html`<strong>Sample Rate:</strong> ${this.escapeHtml(conv.meta.sampleRate.toString())} Hz<br>` : ''}
                </div>
              ` : ''}
              ${conv.meta?.systemPrompt ? html`
                <div class="message system-message">
                  <strong>System Setup:</strong>
                  <div class="message-text">${unsafeHTML(`<pre>${this.escapeHtml(conv.meta.systemPrompt)}</pre>`)}</div>
                </div>
              ` : ''}
              ${conv.messages ? html`
                <div class="messages-list">
                  ${Object.keys(conv.messages).sort((a,b) => (conv.messages[a].timestamp || 0) - (conv.messages[b].timestamp || 0))
                    .map(msgId => {
                      const message = conv.messages[msgId];
                      const speakerLabel = message.speaker === 'model' ? 'WorkflowPro' : 'System'; // Assuming no 'user' messages from this system
                      return html`
                        <div class="message ${this.escapeHtml(message.speaker)}-message">
                          <strong>${this.escapeHtml(speakerLabel)}:</strong>
                          <div class="message-text">${unsafeHTML(this.formatMessageText(message.text))}</div>
                          <small class="timestamp">${new Date(message.timestamp).toLocaleTimeString()}</small>
                        </div>
                      `;
                  })}
                </div>
              ` : ''}
            </div>
          `)}
        </div>
      </div>
    `;
  }

  render() {
    return html`
      <div class="app-container">
        ${this.currentPage === 'settings' ? this.renderSettingsPage() : this.renderMainPage()}
      </div>
      ${this.renderChatHistoryPage()}
    `;
  }
}

if (!process.env.API_KEY) {
  console.error("API_KEY environment variable is not set. The application may not function correctly.");
}
